package ricebowl.oxyflow11;

/**
 * Created by buik1 on 5/22/2017.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "OxyFlow";

    public static final int DATABASE_VERSION = 6;
    public static final String DATABASE_NAME = "OxyFlow.db";

    public static final String TABLE_CONSUMER = "CONSUMER";
    public static final String TABLE_SESSION  = "SESSION";

    public static final String C_ID       = "C_ID";   // CONSUMER ID
    public static final String C_FNAME    = "F_NAME"; // CONSUMER FIRST NAME
    public static final String C_LNAME    = "L_NAME"; // CONSUMER LAST NAME
    public static final String C_EMAIL    = "EMAIL";  // CONSUMER EMAIL
    public static final String C_PASSWORD = "C_PASSWORD";

    public static final String S_ID       = "S_ID";    // SESSION ID
    public static final String S_START    = "S_START"; // SESSION START TIME
    public static final String S_END      = "S_END";   // SESSION END TIME
    public static final String S_USER     = "S_USER";  // SESSION USER
    public static final String S_BRATE    = "S_BRATE"; // SESSION BREATHING RATE

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d(TAG, "Creating Database Tables:" + TABLE_CONSUMER + " and " + TABLE_SESSION);
        db.execSQL("CREATE TABLE " + TABLE_CONSUMER + " ("+ C_ID       + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                                                          + C_FNAME    + " TEXT,"
                                                          + C_LNAME    + " TEXT,"
                                                          + C_EMAIL    + " TEXT,"
                                                          + C_PASSWORD + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_SESSION  + " ("+ S_ID       + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                                                          + S_START    + " TEXT,"
                                                          + S_END      + " TEXT,"
                                                          + S_USER     + " TEXT,"
                                                          + S_BRATE    + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d(TAG, "Upgraded Database:" + DATABASE_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_CONSUMER);
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_SESSION);
        onCreate(db);
    }
    public boolean registration(String first,String last,String email,String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_FNAME,first);
        contentValues.put(C_LNAME,last);
        contentValues.put(C_EMAIL,email);
        contentValues.put(C_PASSWORD,password);
        long result = db.insert(TABLE_CONSUMER, null, contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

    public boolean doesUserExists(String user_email) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sqlQuery = "select * from " + TABLE_CONSUMER + " where " + C_EMAIL + " = \"" + user_email + "\"";
        Log.d(TAG, "doesUserExists: "+ sqlQuery);
        Cursor res = db.rawQuery(sqlQuery, null);
        if(res.getCount() <= 0){
            res.close();
            return false;
        }
        res.close();
        return true;
    }
    public boolean correctLogin(String user_email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        String sqlQuery = "select * from " + TABLE_CONSUMER + " where " + C_EMAIL + " = \"" + user_email + "\" and " + C_PASSWORD + " = \"" + password + "\"";
        Log.d(TAG, "correctPassword: " + sqlQuery);
        Cursor res = db.rawQuery(sqlQuery, null);

        if(res.getCount() <= 0){
            res.close();
            return false;
        }
        res.close();
        return true;
    }
    public Cursor getAllUsers() {
        SQLiteDatabase db = this.getWritableDatabase();
        String sqlQuery = "select * from " + TABLE_CONSUMER;
        Cursor res = db.rawQuery(sqlQuery, null);
        return res;
    }
    public boolean storeSession(String startTime,String endTime,String userEmail,String data){
        Log.d(TAG, "storeSession: Start: " + startTime);
        Log.d(TAG, "storeSession: End:   " + endTime);
        Log.d(TAG, "storeSession: User:  " + userEmail);
        Log.d(TAG, "storeSession: Data   " + data.substring(0,50));

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(S_START,startTime);
        contentValues.put(S_END,endTime);
        contentValues.put(S_USER,userEmail);
        contentValues.put(S_BRATE,data);
        long result = db.insert(TABLE_SESSION, null, contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }


    public Cursor getUserSessions(String user_Email) {
        Log.d(TAG, "getUserSessions: Getting Session Data for " + user_Email);
        SQLiteDatabase db = this.getWritableDatabase();
        String sqlQuery = "select " + S_ID + ", " + S_START + ", " + S_END + ", " + S_USER + " from " + TABLE_SESSION + " where " + S_USER + " = \"" + user_Email + "\"";
        Cursor res = db.rawQuery(sqlQuery, null);
        return res;
    }

    public Cursor getSessionRawData(String sessionID) {
        Log.d(TAG, "getUserSessions: Getting Session Data for SessionID: " + sessionID);
        SQLiteDatabase db = this.getWritableDatabase();
        String sqlQuery = "select " + S_BRATE + " from " + TABLE_SESSION + " where " + S_ID + " = \"" + sessionID + "\"";
        Cursor res = db.rawQuery(sqlQuery, null);
        return res;
    }
}
