package ricebowl.oxyflow11;

/**
 * Created by buik1 on 5/15/2017.
 */

public class XYZValue {
    private double x;
    private double y;
    private double z;
//    private double s;


    public XYZValue(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
//        this.s = s;
    }

    public double getX() {
        return x;
    }
    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }
    public void setY(double y) {
        this.y = y;
    }

    public double getZ() {
        return z;
    }
    public void setZ(double z) {
        this.z = z;
    }

//    public double getS() {
//        return s;
//    }
//    public void setS(double s) {
//        this.s = s;
//    }
}
