package ricebowl.oxyflow11;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.LegendRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.series.PointsGraphSeries;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.UUID;

public class GraphingActivity extends AppCompatActivity {
    private static final String TAG = "OxyFlow";

    // Key variables utilized on android website to connect to bluetooth.

    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
//    static final UUID myUUID = UUID.randomUUID();

    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter btAdapt = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnect = false;

    Context mContext;
    private ConnectedThread mConnectedThread;
    ProgressDialog mProgressDialog;
    TextView incomingMessage;
    StringBuilder messages;

    String stringOutput = "";

    GraphView mScatterPlot;
    PointsGraphSeries<DataPoint> xyPeaks;
    PointsGraphSeries<DataPoint> xySignum;
    LineGraphSeries<DataPoint> xySeries;
    LineGraphSeries<DataPoint> xySmooth;
    private ArrayList<XYZValue> XYZValueArray;
    private ArrayList<XYZValue> XYZSignumArray;
    private ArrayList<XYZValue> XYZPeakArray;
    private double maxY = 1, minY = 0;


    DatabaseHelper db;
    String sessionStart, sessionEnd;
    String userID = null;
    StringBuilder sessionRawData;

    Boolean activeSession = false;

    double calibrateX;
    double calibrateY;
    int calibrateSize;

    boolean raw_data     = false,
            smooth_data  = true,
            peak_to_peak = false,
            sign_change  = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graphing);

        incomingMessage = (TextView) findViewById(R.id.incomingMessage);
        messages = new StringBuilder();
        sessionRawData = new StringBuilder();
        db = new DatabaseHelper(this);

        // Intent to get the EXTRA_ADDRESS from Activity 1
        Intent i = getIntent();
        address = i.getStringExtra(PairingActivity.EXTRA_ADDRESS);
        userID = i.getStringExtra(PairingActivity.EXTRA_EMAIL);
        Log.d(TAG, "onCreate: Received address and userID: " + address + " " + userID);


//        generateData();

        // Calls method to connect to BT. Acquired online.
        new ConnectBT().execute();
        LocalBroadcastManager.getInstance(this).registerReceiver(mReceiver, new IntentFilter("incomingMessage"));

        mScatterPlot = (GraphView) findViewById(R.id.RawData);
    }
    public void Disconnect(View view) {
        if (btSocket!=null){

            mConnectedThread = new ConnectedThread(btSocket);
            mConnectedThread.write("0");
            mConnectedThread.close();
//                btSocket.close(); //close connection
        }
//        Intent i = new Intent(GraphingActivity.this,PairingActivity.class);
//        startActivity(i);
        if (activeSession){
            msg("Stopping");
            sessionEnd = time();
            Log.d(TAG, "Stop: Session stopped at:  " + sessionEnd);
            activeSession = false;
            db.storeSession(sessionStart,sessionEnd,userID,sessionRawData.toString());
        } else { Log.d(TAG, "Stop: Session has not been started."); }

        finish();
    }
    public void Start(View view) {
        if (btSocket!=null){
            if (!activeSession){
//                    btSocket.getOutputStream().write("1".toString().getBytes());
                sessionStart = time();
                Log.d(TAG, "Start: Session started at: " + sessionStart);
                XYZValueArray = new ArrayList<>();
                XYZSignumArray = new ArrayList<>();
                XYZPeakArray = new ArrayList<>();
                mScatterPlot.removeAllSeries();

                sessionRawData.setLength(0);

                beginCalibrate();
                mConnectedThread = new ConnectedThread(btSocket);
                mConnectedThread.write("1");
                activeSession = true;
                msg("Starting");
            } else { Log.d(TAG, "Start: Session is Running."); }

        }
    }
    public void Stop(View view) {
        if (btSocket!=null){
            mConnectedThread = new ConnectedThread(btSocket);
            mConnectedThread.write("0");
//                btSocket.getOutputStream().write("0".toString().getBytes());

            if (activeSession){
                msg("Stopping");
                sessionEnd = time();
                Log.d(TAG, "Stop: Session stopped at:  " + sessionEnd);
                activeSession = false;
                db.storeSession(sessionStart,sessionEnd,userID,sessionRawData.toString());
            } else { Log.d(TAG, "Stop: Session has not been started."); }
        }
    }
    public void Cookie(View view) {
        msg("Here's a cookie!");
    }

    BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String text = intent.getStringExtra("theMessage");
            messages.append(text);
            getDataPoints(messages);
        }
    };

    private void beginCalibrate(){
        calibrateY = 0;
        calibrateSize = 1;
        msg("Calibrating: Don't breath.");
    }
    private void getDataPoints(StringBuilder rawInput){
        for (int i = 0; i < rawInput.length(); i++){
            char c = rawInput.charAt(i);
            if (c == '#'){
                for (int j = 0; j < i; j++){
                    char d = rawInput.charAt(j);
                    if (d == '$'){
                        for (int k = j+1; k<i; k++){
                            char e = rawInput.charAt(k);
                            stringOutput += String.valueOf(e);
                            //Log.d(TAG,"Output: " + stringOutput);
                        }
                        //incomingMessage.setText(stringOutput);
                        separateData(stringOutput);
//                        Log.d(TAG,"Data_Input: " + stringOutput);
                        messages.setLength(0);
                        stringOutput = "";
                        break;
                    }
                }
                break;
            }
        }
    }
    private void separateData(String data){
//        Log.d(TAG, "Began separateData");
        double[] doubleData = new double[2];
        String[] stringData = new String[2];
        int dataPosition = 0;

        for (int i = 0; i< stringData.length; i++){
            stringData[i] = "";
        }
        for (int i = 0; i < data.length(); i++){
            char c = data.charAt(i);
            if (c != '_'){
                stringData[dataPosition] += String.valueOf(c);
            }
            else{
                dataPosition++;
            }
        }
        for (int i = 0; i< stringData.length; i++){
            doubleData[i] = Double.parseDouble(stringData[i]);
        }

        sessionRawData.append(doubleData[1]+"_");


        if (calibrateSize == 1){
            calibrateX = doubleData[0];
            calibrateY = doubleData[1];
            calibrateSize++;
        }
        doubleData[0] -= calibrateX;
        doubleData[1] -= calibrateY;

        if (doubleData[1]<minY){ minY = doubleData[1]; }
        if (doubleData[1]>maxY){ maxY = doubleData[1]; }

        appendData(doubleData[0], doubleData[1]);
    }
    private void appendData(double x, double y){
//        Log.d(TAG, "Began appendData");

        XYZValueArray.add(new XYZValue(x,y,y));
        Log.d(TAG, "X,Y   " + (XYZValueArray.size()-1) + " " + String.format("%.1f", x) + " " + String.format("%.3f", y));
        if (XYZValueArray.size() >= 3){
            int xyzSize = XYZValueArray.size();
            double z = (XYZValueArray.get(xyzSize-3).getY()*1 +
                        XYZValueArray.get(xyzSize-2).getY()*2 +
                        XYZValueArray.get(xyzSize-1).getY()*1 ) / 4;
            XYZValueArray.get(xyzSize-2).setZ(z);
            Log.d(TAG, "X,Y,Z " + (xyzSize-2) + " " + String.format("%.1f", XYZValueArray.get(xyzSize-2).getX()) + " " + String.format("%.3f", XYZValueArray.get(xyzSize-2).getY()) + " " + String.format("%.3f", XYZValueArray.get(xyzSize-2).getZ()));
        }
        if (XYZValueArray.size() >= 4){
            Log.d(TAG, "Array Size: " + XYZValueArray.size());
            int xyzSize = XYZValueArray.size();
            double y1 = (XYZValueArray.get((xyzSize-3)).getZ());
            double x2 = (XYZValueArray.get((xyzSize-2)).getX());
            double z2 = (XYZValueArray.get((xyzSize-2)).getZ());
            Log.d(TAG, "XYZValueArray["+(xyzSize-3)+"] = " + String.format("%.3f", y1));
            Log.d(TAG, "XYZValueArray["+(xyzSize-2)+"] = " + String.format("%.3f", z2));

            // Getting roots when graph crosses from positive value to negative.
            if (Math.signum(y1) != Math.signum(z2) && Math.signum(z2) < 0){
                XYZSignumArray.add(new XYZValue((double)(xyzSize-2) ,x2,z2));

                // Getting Peaks between roots
                if (XYZSignumArray.size() >= 2){
                    double currentMax = XYZSignumArray.get(XYZSignumArray.size()-2).getZ();
                    int maxIndex = Math.round(XYZSignumArray.size()-2);
                    for (int i = (int) XYZSignumArray.get(Math.round(XYZSignumArray.size()-2)).getX(); i < (int) XYZSignumArray.get(Math.round(XYZSignumArray.size()-1)).getX(); i++){
                        if (currentMax < XYZValueArray.get(i).getZ()){
                            currentMax = XYZValueArray.get(i).getZ();
                            maxIndex = i;
                        }
                    }

                    // Plotting peaks
                    double maxX = XYZValueArray.get(maxIndex).getX();
                    double maxZ = XYZValueArray.get(maxIndex).getZ();
                    if (maxZ > 15){
                        XYZPeakArray.add(new XYZValue((double) maxIndex, maxX, maxZ));

                        // Getting Peaks to Peak duration
                        if (XYZPeakArray.size() >= 2){
                            double peak1 = XYZPeakArray.get(XYZPeakArray.size()-2).getY();
                            double peak2 = XYZPeakArray.get(XYZPeakArray.size()-1).getY();
                            double rRate = 60/((peak2-peak1));
                            Log.d(TAG, "appendData: " + peak1 + " " + peak2 + " " + (peak2-peak1));
//                            msg("Respiratory Rate: " + String.format("%.2f", rRate));
                            incomingMessage.setText("Respiratory Rate: " + String.format("%.2f", rRate));
                        }
                    }
                }
            }
            Log.d(TAG, "============================================================");
        }

        if(XYZValueArray.size() != 0){
            createXYZSeries();
            createScatterPlot();
        }else{
            Log.d(TAG, "onCreate: No data to plot.");
        }
    }

    private void createXYZSeries(){
        xySeries = new LineGraphSeries<>();
        xyPeaks = new PointsGraphSeries<>();
        xySignum = new PointsGraphSeries<>();
        xySmooth = new LineGraphSeries<>();

        if (XYZValueArray.size() >= 100){
            for(int i = XYZValueArray.size()-100; i < XYZValueArray.size()-1; i++){
                try{
                    double x = XYZValueArray.get(i).getX();
                    double y = XYZValueArray.get(i).getY();
                    double z = XYZValueArray.get(i).getZ();
                    xySeries.appendData(new DataPoint(x,y),true, 100);
                    xySmooth.appendData(new DataPoint(x,z),true, 100);
                }catch (IllegalArgumentException e){
                    Log.e(TAG, "createScatterPlot: IllegalArgumentException: " + e.getMessage() );
                }
            }
        }
        else{
            for(int i = 0; i < XYZValueArray.size()-1; i++){
                try{
                    double x = XYZValueArray.get(i).getX();
                    double y = XYZValueArray.get(i).getY();
                    double z = XYZValueArray.get(i).getZ();
                    xySeries.appendData(new DataPoint(x,y),true, 100);
                    xySmooth.appendData(new DataPoint(x,z),true, 100);
                }catch (IllegalArgumentException e){
                    Log.e(TAG, "createScatterPlot: IllegalArgumentException: " + e.getMessage() );
                }
            }
        }

        if (XYZSignumArray.size() >= 30){
            for (int i = XYZSignumArray.size()-30; i < XYZSignumArray.size(); i++){
                double x = XYZSignumArray.get(i).getY();
                double z = XYZSignumArray.get(i).getZ();
                xySignum.appendData(new DataPoint(x,z),true, 50);
            }
        }
        else {
            for (int i = 0; i < XYZSignumArray.size(); i++){
                double x = XYZSignumArray.get(i).getY();
                double z = XYZSignumArray.get(i).getZ();
                xySignum.appendData(new DataPoint(x,z),true, 50);
            }
        }

        if (XYZPeakArray.size() >= 10){
            for (int i = XYZPeakArray.size()-10; i < XYZPeakArray.size(); i++){
                double x = XYZPeakArray.get(i).getY();
                double z = XYZPeakArray.get(i).getZ();
                xyPeaks.appendData(new DataPoint(x,z),true, 50);
            }
        }
        else {
            for (int i = 0; i < XYZPeakArray.size(); i++){
                double x = XYZPeakArray.get(i).getY();
                double z = XYZPeakArray.get(i).getZ();
                xyPeaks.appendData(new DataPoint(x,z),true, 50);
            }
        }
    }
    private void createScatterPlot(){
//        Log.d(TAG, "createScatterPlot: Creating scatter plot.");

        //set some properties
//        xySeries.setShape(PointsGraphSeries.Shape.RECTANGLE);
//        xySeries.setColor(Color.BLUE);
//        xySeries.setSize(20f);
//        mScatterPlot.removeAllSeries();
        //set Scrollable and Scalable
        mScatterPlot.removeAllSeries();

        mScatterPlot.getViewport().setScalable(true);
        mScatterPlot.getViewport().setScrollable(true);
        mScatterPlot.getViewport().setScalableY(false);
        mScatterPlot.getViewport().setScrollableY(false);

        //set manual y bounds
        mScatterPlot.getViewport().setYAxisBoundsManual(true);
        mScatterPlot.getViewport().setMaxY(maxY);
        mScatterPlot.getViewport().setMinY(minY);

        //set manual x bounds
        mScatterPlot.getViewport().setXAxisBoundsManual(false);
        mScatterPlot.getViewport().setMaxX(xySmooth.getHighestValueX());
        mScatterPlot.getViewport().setMinX(xySmooth.getHighestValueX()-10);

        xySeries.setTitle("Raw Pressure");
        xySeries.setColor(Color.RED);

        xySmooth.setTitle("Processed Pressure");
        xySmooth.setDrawDataPoints(false);
        xySmooth.setDataPointsRadius(10);
        xySmooth.setThickness(8);

        xySignum.setTitle("Sign Change");
        xySignum.setColor(Color.GREEN);

        xyPeaks.setTitle("Peaks");
        xyPeaks.setColor(Color.YELLOW);

        mScatterPlot.getLegendRenderer().setVisible(true);
        mScatterPlot.getLegendRenderer().setFixedPosition(0,0);

        if (smooth_data)  {mScatterPlot.addSeries(xySmooth);}
        if (raw_data)     {mScatterPlot.addSeries(xySeries);}
        if (sign_change)  {mScatterPlot.addSeries(xySignum);}
        if (peak_to_peak) {mScatterPlot.addSeries(xyPeaks );}
    }
    public void btnClearGraph(View view) {
        mScatterPlot.removeAllSeries();
    }

//    public void onCheckboxClicked(View view) {
//        boolean checked = ((CheckBox) view).isChecked();
//        // Check which checkbox was clicked
//        switch(view.getId()) {
//
//            case R.id.cbRawData:
//                if (checked) {raw_data = true;}
//                else {raw_data = false;}
//            case R.id.cbSmoothData:
//                if (checked) {smooth_data = true;}
//                else {smooth_data = false;}
//            case R.id.cbPeakToPeak:
//                if (checked) {peak_to_peak = true;}
//                else {peak_to_peak = false;}
//            case R.id.cbSignChange:
//                if (checked) {sign_change = true;}
//                else {sign_change = false;}
//        }
//        if (activeSession){
////            mScatterPlot.removeAllSeries();
//            if (raw_data)     { mScatterPlot.addSeries(xySeries); }
//            if (smooth_data)  { mScatterPlot.addSeries(xySmooth); }
//            if (sign_change)  { mScatterPlot.addSeries(xySignum); }
//            if (peak_to_peak) { mScatterPlot.addSeries(xyPeaks); }
//        }
//
//    }

    public void onCheckboxClicked_RawData(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        // Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.cbRawData:
                if (checked) {
                    raw_data = true;
                } else {
                    raw_data = false;
                }
        }
        mScatterPlot.removeAllSeries();
    }

    public void onCheckboxClicked_SmoothData(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        // Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.cbSmoothData:
                if (checked) {
                    smooth_data = true;
                } else {
                    smooth_data = false;
                }
        }
        mScatterPlot.removeAllSeries();
    }

    public void onCheckboxClicked_PeakToPeak(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        // Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.cbPeakToPeak:
                if (checked) {
                    peak_to_peak = true;
                } else {
                    peak_to_peak = false;
                }
        }
        mScatterPlot.removeAllSeries();
    }

    public void onCheckboxClicked_SignChange(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        // Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.cbSignChange:
                if (checked) {
                    sign_change = true;
                } else {
                    sign_change = false;
                }
        }
        mScatterPlot.removeAllSeries();
    }


    private class ConnectBT extends AsyncTask<Void, Void, Void> {
        private boolean ConnectSuccess = true;
        @Override
        protected void onPreExecute(){
            progress = ProgressDialog.show(GraphingActivity.this, "Connecting...", "Please wait!!!");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices){
            try{
                if (btSocket == null || !isBtConnect){
                    btAdapt = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                    BluetoothDevice myBTDevice = btAdapt.getRemoteDevice(address);//connects to the device's address and checks if it's available
                    btSocket = myBTDevice.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();//start connection
                }
            }
            catch (IOException e){
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
//            connected(btSocket);
            return null;
        }
        @Override
        protected void onPostExecute(Void result){
            super.onPostExecute(result);

            if (!ConnectSuccess){
                msg("Connection Failed. Is it a SPP Bluetooth? Try again.");
                finish();
            }
            else{
                msg("Connected.");
                Log.d(TAG, "Connected to: " + address);
                isBtConnect = true;

                mConnectedThread = new ConnectedThread(btSocket);
                mConnectedThread.start();
            }
            progress.dismiss();
        }

    }
    private class ConnectedThread extends Thread {
        private BluetoothSocket mmSocket;
        private InputStream mmInStream;
        private OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            Log.d(TAG, "ConnectedThread: Starting.");

            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;
            //dismiss the progressdialog when connection is established
            try{
                mProgressDialog.dismiss();
            }catch (NullPointerException e){
                e.printStackTrace();
            }

            try {
                tmpIn = mmSocket.getInputStream();
                tmpOut = mmSocket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run(){
            byte[] buffer = new byte[1024];
            int bytes;
            while (true) {
                try {
                    bytes = mmInStream.read(buffer);
                    String incomingMessage = new String(buffer, 0, bytes);
//                    Log.d(TAG, "InputStream: " + incomingMessage);
                    Intent incomingMessageIntent = new Intent("incomingMessage");
                    incomingMessageIntent.putExtra("theMessage", incomingMessage);
                    LocalBroadcastManager.getInstance(mContext).sendBroadcast(incomingMessageIntent);
                } catch (IOException e) {
                    if (mmInStream != null){
                        Log.e(TAG, "write: Error reading Input Stream. " + e.getMessage() );
                    }
                    break;
                }
            }
        }

        public void write(String text) {
            Log.d(TAG, "write: Writing to outputstream: " + text);
            try {
                mmOutStream.write(text.getBytes());
            } catch (IOException e) {
                Log.e(TAG, "write: Error writing to output stream. " + e.getMessage() );
            }
        }

        public void close(){
            if (mmInStream != null) {
                try {
                    mmInStream.close();
                    mmInStream = null;
                    Log.d(TAG, "close: Closed InputStream");
                }
                catch (Exception e) {Log.d(TAG, "close: Failed to close InputStream");}
                try {
                    mmOutStream.close();
                    mmOutStream = null;
                    Log.d(TAG, "close: Closed OutputStream");
                }
                catch (Exception e) {Log.d(TAG, "close: Failed to close OutputStream");}
                try {
                    mmSocket.close();
                    mmSocket = null;
                    Log.d(TAG, "close: Closed Socket");
                }
                catch (IOException e) {Log.d(TAG, "close: Failed to close Socket");}
            }

        }
    }

    private void msg(String s){
        final Toast toast = Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT);
        toast.show();

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                toast.cancel();
            }
        }, 200);
    }
    public String time(){
        DateFormat formatDate = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z");
        // Example: Mon, 31 Jul 2017 15:58:25 EDT
        String date = formatDate.format(Calendar.getInstance().getTime());
        return date;
    }

    public void generateData(){
        for (int i = 1; i<36000; i++){
            sessionRawData.append("123.4_");
        }
        Log.d(TAG, "generateData: sessionRawData.length() = " + sessionRawData.length());
    }
//package ricebowl.oxyflow11;
//
//import android.app.ProgressDialog;
//import android.bluetooth.BluetoothAdapter;
//import android.bluetooth.BluetoothDevice;
//import android.bluetooth.BluetoothSocket;
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.content.IntentFilter;
//import android.graphics.Color;
//import android.os.AsyncTask;
//import android.os.Handler;
//import android.support.v4.content.LocalBroadcastManager;
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.View;
//import android.widget.Button;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.jjoe64.graphview.GraphView;
//import com.jjoe64.graphview.series.DataPoint;
//import com.jjoe64.graphview.series.LineGraphSeries;
//import com.jjoe64.graphview.series.PointsGraphSeries;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.UUID;
//
//public class GraphingActivity extends AppCompatActivity {
//    private static final String TAG = "OxyFlow";
//
//    // Key variables utilized on android website to connect to bluetooth.
//
//    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
////    static final UUID myUUID = UUID.randomUUID();
//
//    String address = null;
//    private ProgressDialog progress;
//    BluetoothAdapter btAdapt = null;
//    BluetoothSocket btSocket = null;
//    private boolean isBtConnect = false;
//
//    Context mContext;
//    private ConnectedThread mConnectedThread;
//    ProgressDialog mProgressDialog;
//    TextView incomingMessage;
//    StringBuilder messages;
//
//    String stringOutput = "";
//
//    GraphView mScatterPlot;
//    LineGraphSeries<DataPoint> xySeries;
//    PointsGraphSeries<DataPoint> xyPeaks;
//    ArrayList<Double> xCoord;
//    ArrayList<Double> yCoord;
//    ArrayList<Integer> signChange;
//    double lastSign = 0;
//    private double maxY = 1, minY = 0;
//
//    DatabaseHelper db;
//    String sessionStart, sessionEnd;
//    String userID = null;
//    StringBuilder sessionRawData;
//
//    Boolean activeSession = false;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_graphing);
//
//        incomingMessage = (TextView) findViewById(R.id.incomingMessage);
//        messages = new StringBuilder();
//        sessionRawData = new StringBuilder();
//        db = new DatabaseHelper(this);
//
//        // Intent to get the EXTRA_ADDRESS from Activity 1
//        Intent i = getIntent();
//        address = i.getStringExtra(PairingActivity.EXTRA_ADDRESS);
//        userID = i.getStringExtra(PairingActivity.EXTRA_EMAIL);
//        Log.d(TAG, "onCreate: Received address and userID: " + address + " " + userID);
//
////        generateData();
//
//        // Calls method to connect to BT. Acquired online.
//        new ConnectBT().execute();
//        LocalBroadcastManager.getInstance(this).registerReceiver(mReceiver, new IntentFilter("incomingMessage"));
//
//        mScatterPlot = (GraphView) findViewById(R.id.scatterPlot);
//    }
//
//    public void Disconnect(View view) {
//        if (btSocket!=null){
//            try{
//                btSocket.close(); //close connection
//            }
//            catch (IOException e){
//                msg("Error");
//            }
//        }
//        Intent i = new Intent(GraphingActivity.this,LoginActivity.class);
//        startActivity(i);
//        finish();
//    }
//    public void Start(View view) {
//        if (btSocket!=null){
//            try{
//                if (!activeSession){
//                    btSocket.getOutputStream().write("1".toString().getBytes());
//                    msg("Starting");
//                    sessionStart = time();
//                    Log.d(TAG, "Start: Session started at: " + sessionStart);
//                    activeSession = true;
//                    xySeries = new LineGraphSeries<>();
//                    xyPeaks = new PointsGraphSeries<>();
//                    xCoord = new ArrayList<>();
//                    yCoord = new ArrayList<>();
//                } else { Log.d(TAG, "Start: Session is Running."); }
//
//            }
//            catch (IOException e){
//                msg("Error");
//            }
//        }
//    }
//    public void Stop(View view) {
//        if (btSocket!=null){
//            try{
//                btSocket.getOutputStream().write("0".toString().getBytes());
//                if (activeSession){
//                    msg("Stopping");
//                    sessionEnd = time();
//                    Log.d(TAG, "Stop: Session stopped at:  " + sessionEnd);
//                    activeSession = false;
//                    db.storeSession(sessionStart,sessionEnd,userID,sessionRawData.toString());
//                    sessionRawData.setLength(0);
//
//                } else { Log.d(TAG, "Stop: Session has not been started."); }
//            }
//            catch (IOException e){
//                msg("Error");
//            }
//        }
//    }
//    public void Cookie(View view) {
//        msg("Here's a cookie!");
//    }
//
//    BroadcastReceiver mReceiver = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            String text = intent.getStringExtra("theMessage");
//            messages.append(text);
//            getDataPoints(messages);
//        }
//    };
//
//    private void getDataPoints(StringBuilder rawInput){
//        for (int i = 0; i < rawInput.length(); i++){
//            char c = rawInput.charAt(i);
//            if (c == '#'){
//                for (int j = 0; j < i; j++){
//                    char d = rawInput.charAt(j);
//                    if (d == '$'){
//                        for (int k = j+1; k<i; k++){
//                            char e = rawInput.charAt(k);
//                            stringOutput += String.valueOf(e);
//                            //Log.d(TAG,"Output: " + stringOutput);
//                        }
//                        //incomingMessage.setText(stringOutput);
//                        separateData(stringOutput);
//                        Log.d(TAG,"Output: " + stringOutput);
//                        messages.setLength(0);
//                        stringOutput = "";
//                        break;
//                    }
//                }
//                break;
//            }
//        }
//    }
//    private void separateData(String data){
//        Log.d(TAG, "Began separateData");
//        double[] doubleData = new double[2];
//        String[] stringData = new String[2];
//        int dataPosition = 0;
//
//        for (int i = 0; i< stringData.length; i++){
//            stringData[i] = "";
//        }
//        for (int i = 0; i < data.length(); i++){
//            char c = data.charAt(i);
//            if (c != '_'){
//                stringData[dataPosition] += String.valueOf(c);
//            }
//            else{
//                dataPosition++;
//            }
//        }
//        for (int i = 0; i< stringData.length; i++){
//            doubleData[i] = Double.parseDouble(stringData[i]);
//        }
//
//        sessionRawData.append(stringData[1]+"_");
//        incomingMessage.setText("X: " + doubleData[0] + " and Y: " + doubleData[1]);
//
//        if (doubleData[1]<minY){
//            minY = doubleData[1];
//        }
//        if (doubleData[1]>maxY){
//            maxY = doubleData[1];
//        }
//        appendData(doubleData[0], doubleData[1]);
//    }
//    private void appendData(double x, double y){
//        Log.d(TAG, "Began appendData");
//
//        xCoord.add(x);
//        yCoord.add(y);
//
//        if (lastSign != Math.signum(y)){
//            signChange.add(xCoord.size()-1);
//            lastSign = Math.signum(y);
//        }
//        if (signChange.size() < 1 && Math.signum(y) != -1){
//            int maxIndex = signChange.size() - 2;
//            for (int i = signChange.get(signChange.size() - 2); i < signChange.get(signChange.size()-1); i++){
//                if (yCoord.get(i) > yCoord.get(maxIndex)){
//                    maxIndex = i;
//                }
//            }
//            xyPeaks.appendData(new DataPoint(xCoord.get(maxIndex), yCoord.get(maxIndex)),true,100);
//        }
//
//        xyPeaks.setShape(PointsGraphSeries.Shape.RECTANGLE);
//        xyPeaks.setColor(Color.BLUE);
//        xyPeaks.setSize(20f);
//
//        xySeries.appendData(new DataPoint(x,y),true, 100);
//        xySeries.setTitle("Respiratory Rate");
////        xySeries.setDrawDataPoints(true);
////        xySeries.setDataPointsRadius(10);
////        xySeries.setThickness(8);
//
//        //set Scrollable and Scaleable
//        mScatterPlot.getViewport().setScalable(false);
//        mScatterPlot.getViewport().setScalableY(false);
//        mScatterPlot.getViewport().setScrollable(false);
//        mScatterPlot.getViewport().setScrollableY(false);
//
//        //set manual y bounds
//        mScatterPlot.getViewport().setYAxisBoundsManual(true);
//        mScatterPlot.getViewport().setMaxY(maxY);
//        mScatterPlot.getViewport().setMinY(minY);
//
//
//        //set manual x bounds
//        mScatterPlot.getViewport().setXAxisBoundsManual(true);
//        mScatterPlot.getViewport().setMaxX(xySeries.getHighestValueX());
//        mScatterPlot.getViewport().setMinX(xySeries.getHighestValueX()-2*Math.PI);
//
//        mScatterPlot.addSeries(xySeries);
//        mScatterPlot.addSeries(xyPeaks);
//    }
//
//    private class ConnectBT extends AsyncTask<Void, Void, Void> {
//        private boolean ConnectSuccess = true;
//        @Override
//        protected void onPreExecute(){
//            progress = ProgressDialog.show(GraphingActivity.this, "Connecting...", "Please wait!!!");  //show a progress dialog
//        }
//
//        @Override
//        protected Void doInBackground(Void... devices){
//            try{
//                if (btSocket == null || !isBtConnect){
//                    btAdapt = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
//                    BluetoothDevice myBTDevice = btAdapt.getRemoteDevice(address);//connects to the device's address and checks if it's available
//                    btSocket = myBTDevice.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
//                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
//                    btSocket.connect();//start connection
//                }
//            }
//            catch (IOException e){
//                ConnectSuccess = false;//if the try failed, you can check the exception here
//            }
//            connected(btSocket);
//            return null;
//        }
//        @Override
//        protected void onPostExecute(Void result){
//            super.onPostExecute(result);
//
//            if (!ConnectSuccess){
//                msg("Connection Failed. Is it a SPP Bluetooth? Try again.");
//                finish();
//            }
//            else{
//                msg("Connected.");
//                Log.d(TAG, "Connected to: " + address);
//                isBtConnect = true;
//            }
//            progress.dismiss();
//        }
//
//    }
//    private void connected(BluetoothSocket mmSocket) {
//        Log.d(TAG, "connected: Starting.");
//
//        // Start the thread to manage the connection and perform transmissions
//        mConnectedThread = new ConnectedThread(mmSocket);
//        mConnectedThread.start();
//    }
//    /**
//     Finally the ConnectedThread which is responsible for maintaining the BTConnection, Sending the data, and
//     receiving incoming data through input/output streams respectively.
//     **/
//    private class ConnectedThread extends Thread {
//        private final BluetoothSocket mmSocket;
//        private final InputStream mmInStream;
//
//        public ConnectedThread(BluetoothSocket socket) {
//            Log.d(TAG, "ConnectedThread: Starting.");
//
//            mmSocket = socket;
//            InputStream tmpIn = null;
//
//            //dismiss the progressdialog when connection is established
//            try{
//                mProgressDialog.dismiss();
//            }catch (NullPointerException e){
//                e.printStackTrace();
//            }
//
//            try {
//                tmpIn = mmSocket.getInputStream();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//
//            mmInStream = tmpIn;
//        }
//
//        public void run(){
//            byte[] buffer = new byte[1024];
//            int bytes;
//            while (true) {
//                try {
//                    bytes = mmInStream.read(buffer);
//                    String incomingMessage = new String(buffer, 0, bytes);
//                    Log.d(TAG, "InputStream: " + incomingMessage);
//                    Intent incomingMessageIntent = new Intent("incomingMessage");
//                    incomingMessageIntent.putExtra("theMessage", incomingMessage);
//                    LocalBroadcastManager.getInstance(mContext).sendBroadcast(incomingMessageIntent);
//                } catch (IOException e) {
//                    Log.e(TAG, "write: Error reading Input Stream. " + e.getMessage() );
//                    break;
//                }
//            }
//        }
//    }
//
//    private void msg(String s){
//        final Toast toast = Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT);
//        toast.show();
//
//        Handler handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                toast.cancel();
//            }
//        }, 50);
//    }
//    public String time(){
//        DateFormat formatDate = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z");
//        // Example: Mon, 31 Jul 2017 15:58:25 EDT
//        String date = formatDate.format(Calendar.getInstance().getTime());
//        return date;
//    }
//
//    public void generateData(){
//        for (int i = 1; i<36000; i++){
//            sessionRawData.append("123.4_");
//        }
//        Log.d(TAG, "generateData: sessionRawData.length() = " + sessionRawData.length());
//    }
//
//}

}


