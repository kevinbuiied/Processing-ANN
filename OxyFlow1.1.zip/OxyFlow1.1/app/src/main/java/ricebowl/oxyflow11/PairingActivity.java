package ricebowl.oxyflow11;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.database.Cursor;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

public class PairingActivity extends AppCompatActivity {
    private static final String TAG = "OxyFlow";

    DatabaseHelper db;

    ListView deviceList;
    private BluetoothAdapter btAdapt = null;
    private Set<BluetoothDevice> pairedDevices;
    public static String EXTRA_ADDRESS = "device_address";
    public static String EXTRA_EMAIL = "user_email";
    String userID = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pairing);
        deviceList = (ListView)findViewById(R.id.listView);
        btAdapt = BluetoothAdapter.getDefaultAdapter();

        db = new DatabaseHelper(this);
        Intent i = getIntent();
        userID = i.getStringExtra(LoginActivity.loginID);

        if(btAdapt == null){
            msg("This device is not Bluetooth Enabled");
            finish();
        }
        else if(!btAdapt.isEnabled()){
            Intent turnBTon = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(turnBTon,1);
            pairedDevicesList();
        }
        pairedDevicesList();
    }

    private void pairedDevicesList(){
        pairedDevices = btAdapt.getBondedDevices();
        ArrayList theList = new ArrayList();

        if (pairedDevices.size()>0){
            for (BluetoothDevice bt : pairedDevices){
                theList.add(bt.getName() + "\n" + bt.getAddress());
            }
        }
        else{
            msg("No Paired Bluetooth Devices Found.");
        }
        final ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,theList);
        deviceList.setAdapter(adapter);
        deviceList.setOnItemClickListener(myListClickListener);
    }

    private AdapterView.OnItemClickListener myListClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String info = ((TextView) view).getText().toString();
            String address = info.substring(info.length() - 17);
            Intent i = new Intent(PairingActivity.this,GraphingActivity.class);
            i.putExtra(EXTRA_ADDRESS, address);
            i.putExtra(EXTRA_EMAIL, userID);
            Log.d(TAG, "Attempting to Connect to: " + info.substring(0,info.length()-18) + info.substring(info.length() - 17));
            Log.d(TAG, "Passing Address: " + address + " and userID: " + userID + " onto Graphing Activity" );
            startActivity(i);
        }
    };
    // Easy way to make Toast
    private void msg(String s){
        final Toast toast = Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT);
        toast.show();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable(){
            @Override
            public void run(){
                toast.cancel();
            }
        }, 250);
    }

    public void ListSessions(View view) {
        Intent i = new Intent(PairingActivity.this,PastSessionsActivity.class);
        i.putExtra(EXTRA_EMAIL, userID);
        Log.d(TAG, "Passing userID: " + userID + " onto PastSessionActivity" );
        startActivity(i);

    }

    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

    public void btnRefresh(View view) {
        pairedDevicesList();
    }
}
