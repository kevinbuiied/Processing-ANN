package ricebowl.oxyflow11;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "OxyFlow";

    public static String loginID = "email_login";
    DatabaseHelper db;
    EditText etEmail_Login, etPassword_Login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = new DatabaseHelper(this);

        if (!db.doesUserExists("guest@guest.guest")){
            Log.d(TAG, "Creating Guest Account");
            db.registration("Guest", "Guest", "guest@guest.guest", "guest");
        }

        etEmail_Login    = (EditText) findViewById(R.id.etEmail_Login);
        etPassword_Login = (EditText) findViewById(R.id.etPassword_Login);

    }
    public void Login(View view) {
        Log.d(TAG, "Clicked Login Button");
        String email = etEmail_Login.getText().toString().toLowerCase();
        String password = etPassword_Login.getText().toString().toLowerCase();

        if(db.correctLogin(email,password)){
            msg("Successful Login");
            Intent i = new Intent(LoginActivity.this,PairingActivity.class);
            i.putExtra(loginID, email);
            startActivity(i);
        } else{ msg("Incorrect Login"); }

    }
    public void Register(View view) {
        Log.d(TAG, "Clicked Register Button");
        Intent i = new Intent(LoginActivity.this,RegistrationActivity.class);
        startActivity(i);
        finish();
    }
    public void Info(View view) {
        Cursor res = db.getAllUsers();
        if(res.getCount() == 0) {
            // show message
            showMessage("Error","Nothing found");
            return;
        }

        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            buffer.append("ID :"       + res.getString(0) + "\n");
            buffer.append("First :"    + res.getString(1) + "\n");
            buffer.append("Last :"     + res.getString(2) + "\n");
            buffer.append("Email :"    + res.getString(3) + "\n");
            buffer.append("Password :" + res.getString(4) + "\n\n");
        }

        // Show all data
        showMessage("Data",buffer.toString());
    }

    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
    private void msg(String s){
        final Toast toast = Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT);
        toast.show();

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                toast.cancel();
            }
        }, 550);
    }

    public void Guest(View view) {
        Intent i = new Intent(LoginActivity.this,PairingActivity.class);
        i.putExtra(loginID, "guest@guest.guest");
        startActivity(i);
    }
}
