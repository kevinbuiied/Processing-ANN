package ricebowl.oxyflow11;

import android.app.AlertDialog;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.series.PointsGraphSeries;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class PastSessionsActivity extends AppCompatActivity {
    private static final String TAG = "OxyFlow";

    DatabaseHelper db;
    ListView pastSessions;
    String userID;

    TextView tvSessionID;

    GraphView sessionGraphWindow;
    LineGraphSeries<DataPoint> xySeries;
    PointsGraphSeries<DataPoint> xySeriesCriticalValues;
    LineGraphSeries<DataPoint> xySmooth;
    PointsGraphSeries<DataPoint> xySmoothPeaks;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_past_sessions);
        db = new DatabaseHelper(this);
        pastSessions = (ListView)findViewById(R.id.lvPastSessions);

        tvSessionID = (TextView) findViewById(R.id.tvSessionID);

        // Intent to get the EXTRA_ADDRESS from Activity 1
        Intent i = getIntent();
        userID = i.getStringExtra(PairingActivity.EXTRA_EMAIL);
        Log.d(TAG, "onCreate: Received userID: \"" + userID + "\"");

        pastSessionsList();

        //===Graphing Code=============>
        sessionGraphWindow = (GraphView) findViewById(R.id.gvLinePlot);
    }

    private void pastSessionsList(){

        ArrayList theList = new ArrayList();

        Cursor res = db.getUserSessions(userID);
        if(res.getCount() == 0) {
            // show message
            showMessage("Error","Nothing found");
            return;
        }

        while (res.moveToNext()) {
            theList.add("ID: "    + res.getString(0) + "\n" +
                        "Start: " + res.getString(1) + "\n" +
                        "End:   " + res.getString(2) + "\n" +
                        "User:  " + res.getString(3));
        }

        final ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,theList);
        pastSessions.setAdapter(adapter);
        pastSessions.setOnItemClickListener(lvPastSessionOnClickListener);
    }

    private AdapterView.OnItemClickListener lvPastSessionOnClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            // Gets all text from the selected listview item, converts to string, separates by line,
            // separates the first line by space, and gets the integer ID in index 1
            String sessionID = ((TextView) view).getText().toString().split("\n")[0].split(" ")[1];
            tvSessionID.setText("Session ID: " + sessionID);
            //===Get Respiratory Data from selection=====================>
            Cursor dbCursor = db.getSessionRawData(sessionID);
            if(dbCursor.getCount() == 0) {
                showMessage("Error","Nothing found");
                return;
            }
            StringBuffer buffer = new StringBuffer();
            while (dbCursor.moveToNext()) {
                buffer.append(dbCursor.getString(0));
            }
            String[] dataString = buffer.toString().replace("\n", "").split("_");
            //===Convert String data to Double data=====================>
            sessionGraphWindow.removeAllSeries();
            xySeries = new LineGraphSeries<>();
            xySeriesCriticalValues = new PointsGraphSeries<>();
            xySmooth = new LineGraphSeries<>();
            xySmoothPeaks = new PointsGraphSeries<>();

            String respiratory_rate = "";
            boolean analyze = false;
            double above_zero = 0;
            double[] dataDouble = new double[dataString.length];
            ArrayList<Integer> criticalIndex = new ArrayList<>();
            ArrayList<Integer> criticalPeaks = new ArrayList<>();
            for (int i = 0; i<dataString.length; i++){
                dataDouble[i] = Double.parseDouble(dataString[i]);
                xySeries.appendData(new DataPoint(i*0.1,dataDouble[i]),true,dataDouble.length);
            }

            double[] smoothData = new double[dataDouble.length];
            for (int i = 0; i<2; i++){
                smoothData[i] = dataDouble[i];
                smoothData[dataDouble.length-i-1] = dataDouble[dataDouble.length-i-1];
            }
            for (int i = 2; i<dataDouble.length-2; i++){
                smoothData[i] = (1*dataDouble[i-1]+2*dataDouble[i]+1*dataDouble[i+1])/4;
            }
            for (int i = 0; i<smoothData.length-1; i++){
                xySmooth.appendData(new DataPoint(i*0.1,smoothData[i]),true,smoothData.length);
                if (!analyze && smoothData[i]>25){
                    analyze = true;
                    above_zero = Math.signum(smoothData[i]);
                    xySeriesCriticalValues.appendData(new DataPoint(i*0.1,smoothData[i]),true,smoothData.length);
                    criticalIndex.add(i);
                }
                if (analyze && Math.signum(smoothData[i]) != above_zero){
                    criticalIndex.add(i);

                    Log.d(TAG, "onItemClick: criticalIndex size: "+ smoothData.length + " " + criticalIndex.get(criticalIndex.size()-2) + " " + criticalIndex.get(criticalIndex.size()-1));

                    if (Math.signum(smoothData[i])==-1){
                        double maxY = smoothData[criticalIndex.get(criticalIndex.size() - 2)];
                        int maxX = criticalIndex.get(criticalIndex.size() - 2);
                        for (int j = criticalIndex.get(criticalIndex.size() - 2); j<criticalIndex.get(criticalIndex.size()-1); j++){
                            if (maxY < smoothData[j]) {
                                maxY = smoothData[j];
                                maxX = j;
                            }
                        }
                        if (maxY > 20){
                            Log.d(TAG, "onItemClick: Max x and Max y peaks: " + maxX + " " + maxY);
                            criticalPeaks.add(maxX);
                            xySmoothPeaks.appendData(new DataPoint(maxX*0.1,maxY),true,smoothData.length);
                        }

                        if (criticalPeaks.size()>1){
                            double n = 60/((criticalPeaks.get(criticalPeaks.size()-1)-criticalPeaks.get(criticalPeaks.size()-2))*0.1);
                            String s = String.format("%.1f\n", n);
                            respiratory_rate += s;
                        }
                    }
                    xySeriesCriticalValues.appendData(new DataPoint(i*0.1,smoothData[i]),true,smoothData.length);
                    above_zero = above_zero*-1.0;
                }
            }
            createLineGraph();
            msg(respiratory_rate);
        }
    };

    private void createLineGraph(){

        xySeries.setDrawDataPoints(true);

        xySmooth.setDrawDataPoints(false);
        xySmooth.setDataPointsRadius(10);
        xySmooth.setThickness(8);
        xySmooth.setColor(Color.RED);

        xySeriesCriticalValues.setShape(PointsGraphSeries.Shape.RECTANGLE);
        xySeriesCriticalValues.setColor(Color.BLUE);
        xySeriesCriticalValues.setSize(20f);

        //set Scrollable and Scaleable
        sessionGraphWindow.getViewport().setScalable(true);
        sessionGraphWindow.getViewport().setScalableY(false);
        sessionGraphWindow.getViewport().setScrollable(true);
        sessionGraphWindow.getViewport().setScrollableY(false);

        //set manual y bounds
        sessionGraphWindow.getViewport().setYAxisBoundsManual(true);
        sessionGraphWindow.getViewport().setMaxY(xySmooth.getHighestValueY());
        sessionGraphWindow.getViewport().setMinY(xySmooth.getLowestValueY());

        //set manual x bounds
        sessionGraphWindow.getViewport().setXAxisBoundsManual(true);
        sessionGraphWindow.getViewport().setMaxX(xySmooth.getHighestValueX());
        sessionGraphWindow.getViewport().setMinX(xySmooth.getLowestValueX());

        Log.d(TAG, xySmooth.getLowestValueX() + " " + xySmooth.getHighestValueX() + " " + xySmooth.getHighestValueX() + " " + xySmooth.getHighestValueX());
//        sessionGraphWindow.addSeries(xySeries);
        sessionGraphWindow.addSeries(xySeriesCriticalValues);
        sessionGraphWindow.addSeries(xySmooth);
        sessionGraphWindow.addSeries(xySmoothPeaks);
    }

    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
    private void msg(String s){
        final Toast toast = Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT);
        toast.show();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable(){
            @Override
            public void run(){
                toast.cancel();
            }
        }, 500);
    }

}
