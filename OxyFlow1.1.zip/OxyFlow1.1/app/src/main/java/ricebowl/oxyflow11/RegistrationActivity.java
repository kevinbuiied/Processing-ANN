package ricebowl.oxyflow11;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrationActivity extends AppCompatActivity {
    private static final String TAG = "OxyFlow";
    DatabaseHelper db;
    EditText etFirst_Reg, etLast_Reg, etEmail_Reg, etPassword_Reg;

    String First, Last, Email, Pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        db = new DatabaseHelper(this);

        etFirst_Reg    = (EditText) findViewById(R.id.etFirst_Reg);
        etLast_Reg     = (EditText) findViewById(R.id.etLast_Reg);
        etEmail_Reg    = (EditText) findViewById(R.id.etEmail_Reg);
        etPassword_Reg = (EditText) findViewById(R.id.etPassword_Reg);
    }

    public void Return(View view) {
        Log.d(TAG, "Clicked Return");
        Intent i = new Intent(RegistrationActivity.this,LoginActivity.class);
        startActivity(i);
        finish();
    }
    public void Register(View view) {
        Log.d(TAG, "Clicked Register. Registering User");

        Boolean success = attemptReg();
        if (success){
            db.registration(First, Last, Email, Pass);
            msg("Registration Successful");
            Intent i = new Intent(RegistrationActivity.this,LoginActivity.class);
            startActivity(i);
            finish();
        }
    }

    public boolean attemptReg(){
        etFirst_Reg.setError(null);
        etLast_Reg.setError(null);
        etPassword_Reg.setError(null);
        etEmail_Reg.setError(null);

        First = firstLetterUppercase(etFirst_Reg.getText().toString());
        Last = firstLetterUppercase(etLast_Reg.getText().toString());
        Email = etEmail_Reg.getText().toString().toLowerCase();
        Pass = etPassword_Reg.getText().toString().toLowerCase();

        boolean cancel = false;
        View focusView = null;

        if(TextUtils.isEmpty(First)){
            Log.d(TAG, "attemptReg: No First Name");
            etFirst_Reg.setError("Please enter First Name");
            focusView = etFirst_Reg;
            cancel = true;
        }

        if (TextUtils.isEmpty(Last)){
            Log.d(TAG, "attemptReg: No Last Name");
            etLast_Reg.setError("Please enter a Last Name");
            focusView = etLast_Reg;
            cancel = true;
        }

        if (TextUtils.isEmpty(Pass)){
            Log.d(TAG, "attemptReg: No Password");
            etPassword_Reg.setError("Password is bad");
            focusView = etPassword_Reg;
            cancel = true;
        }

        if (TextUtils.isEmpty(Email)){
            Log.d(TAG, "attemptReg: No Email");
            etEmail_Reg.setError("Please Enter Email");
            focusView = etEmail_Reg;
            cancel = true;
        }
        else if(!isValidEmail(Email)){
            Log.d(TAG, "attemptReg: Invalid Email");
            etEmail_Reg.setError("Invalid Email");
            focusView = etEmail_Reg;
            cancel = true;
        }
        else if(db.doesUserExists(Email)){
            Log.d(TAG, "attemptReg: Email Already Exists");
            etEmail_Reg.setError("Email Already Exists");
            focusView = etEmail_Reg;
            cancel = true;
        }


        if(cancel){
            focusView.requestFocus();
            return false; // Does not register
        }
        return true;
    }

    public String firstLetterUppercase(String inputVal) {
        if (inputVal.length() == 0)
            return "";
        if (inputVal.length() == 1)
            return inputVal.toUpperCase();
        return inputVal.substring(0,1).toUpperCase() + inputVal.substring(1).toLowerCase();
    }
    public final static boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }
    private void msg(String s){
        final Toast toast = Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT);
        toast.show();

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                toast.cancel();
            }
        }, 150);
    }
}
